#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  1 15:56:49 2019

@author: eder
"""

import sistema
import numpy as np
k=1
npg_s = 8   # Número de pontos de Gauss para a integração singular
npg_r = 6   # Número de pontos de Gauss para a integração regular
qsil,w1 = np.polynomial.legendre.leggauss(npg_r); # Pontos e pesos de Gauss para a integração regular (triângulo)
qsi_quad,w_quad = np.polynomial.legendre.leggauss(npg_s) # Pontos e pesos de Gauss para a integração singular (quadrilátero)

a=0
b=1
eta = 0.5*(qsil + 1)*(b - a) + a
w2=w1*0.5*(b - a)

N1 = np.zeros((npg_r,npg_r))
N2 = np.zeros((npg_r,npg_r))
for l in range(0,npg_r):
    for m in range(0,npg_r):
        N1[l,m] = (1-eta[m])*eta[l] # qsi escrito como qsi_linha e eta
        N2[l,m] = eta[m]

N3 = 1-N1-N2

dNdqsi = np.array([1,0,-1])
dNdeta = np.array([0,1,-1])

Xd = np.array([0,0,0])
X1 = np.array([0,0,0])
X2 = np.array([1,1,0])
X3 = np.array([1,0,0])
n = sistema.calc_vetnormal(X1,X2,X3)    # Vetor unitário normal ao elemento
J = sistema.calc_jacobiano(X1,X2,X3,dNdqsi,dNdeta)  # Jacobiano do elemento

g = sistema.calcula_Gs(X1,X2,X3,Xd,qsi_quad,w_quad,k)
